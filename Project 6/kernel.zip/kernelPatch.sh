#!/bin/bash

echo "DIFF STAGE"
diff -burN clean-4.4.50 linux-4.4.50 > g12-s04-source.patch
