#!/bin/bash

read -p 'Compile modules or not [y/n]: ' compileMods

cd /home/thibaultrenaud/OS/linux-4.4.50
echo "Making old config\n"
make ARCH=i386 oldconfig
export ARCH=i386
make oldconfig

echo "Compiling kernel\n"
make ARCH=i386 bzImage -j5

if [ 'y' = "$compileMods" ];
then
        echo "Compiling modules"
        make ARCH=i386 modules -j5
else
        echo "Won't compile modules!"
fi


mkdir /home/thibaultrenaud/OS/boot
echo "Exporting install path\n"
export INSTALL_PATH=/home/thibaultrenaud/OS/boot
mkdir /home/thibaultrenaud/OS/mods
echo "Exporting mods install path\n"
export INSTALL_MOD_PATH=/home/thibaultrenaud/OS/mods
echo "Installing kernel\n"
make ARCH=i386 install -j5

if [ 'y' = "$compileMods" ];
then
	echo "Installing modules\n"
	make ARCH=i386 modules_install -j5
else
        echo "Won't install modules!"
fi
